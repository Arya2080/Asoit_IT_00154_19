<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MYSQL</title>
</head>
<body>
    <?php
    echo "Welcome for connect a database <br>";
    $servername = "localhost";
    $username = "root";
    $password = "";

    $conn = mysqli_connect($servername, $username, $password);
    if(!$conn)
    {
        die("Sorry we faild to connect: ".mysqli_connect_error());


    }
    else{
        echo " Connection was successful";
    }
    ?>
</body>
</html>